from setuptools import setup, find_packages

setup(
    name='color_print',
    version='0.1',
    description='Une librairie pour faire imprimer en couleur à l\'écran',
    author='Romain Dudek',
    packages=find_packages(),
    install_requires=[
    ],
)