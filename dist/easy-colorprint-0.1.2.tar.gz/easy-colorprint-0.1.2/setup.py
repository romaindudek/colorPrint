from setuptools import setup, find_packages

setup(
    name='easy-colorprint',
    version='0.1.2',
    description='Une librairie pour imprimer en couleur à l\'écran',
    author='Romain Dudek',
    packages=find_packages(),
    install_requires=[
    ],
)